# Student Manager - ICT261 Classroom Lab

This application adapts the classroom Customer Manager lab into a Student Manager.

Fields:
- Name
- Student Number
- Course
- Program

The application implements:
1. A form with student information fields.
2. A Student class and ObservableList<Student>.
3. A TableView with Name, Student Number, Course and Program columns.
4. Input validation before adding a student.
5. Confirmation before deleting a selected student.
6. Invalid-input testing and keyboard access.

Files:
- Student.java
- StudentManager.java

Run StudentManager.java using your JavaFX configuration.
