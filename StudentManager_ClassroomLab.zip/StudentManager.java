package studentmanager;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class StudentManager extends Application {

    private final ObservableList<Student> students =
            FXCollections.observableArrayList();

    private final TextField nameField = new TextField();
    private final TextField studentNumberField = new TextField();
    private final TextField courseField = new TextField();
    private final TextField programField = new TextField();

    private final TableView<Student> table = new TableView<>();

    @Override
    public void start(Stage stage) {
        stage.setTitle("Student Manager");

        // Form fields
        nameField.setPromptText("Enter student name");
        studentNumberField.setPromptText("Enter student number");
        courseField.setPromptText("Enter course");
        programField.setPromptText("Enter program");

        // Table columns
        TableColumn<Student, String> nameColumn =
                new TableColumn<>("Name");
        nameColumn.setCellValueFactory(
                new PropertyValueFactory<>("name"));

        TableColumn<Student, String> numberColumn =
                new TableColumn<>("Student Number");
        numberColumn.setCellValueFactory(
                new PropertyValueFactory<>("studentNumber"));

        TableColumn<Student, String> courseColumn =
                new TableColumn<>("Course");
        courseColumn.setCellValueFactory(
                new PropertyValueFactory<>("course"));

        TableColumn<Student, String> programColumn =
                new TableColumn<>("Program");
        programColumn.setCellValueFactory(
                new PropertyValueFactory<>("program"));

        nameColumn.setPrefWidth(150);
        numberColumn.setPrefWidth(130);
        courseColumn.setPrefWidth(150);
        programColumn.setPrefWidth(180);

        table.getColumns().addAll(
                nameColumn,
                numberColumn,
                courseColumn,
                programColumn
        );

        table.setItems(students);
        table.setPlaceholder(new Label("No students added yet."));

        // Buttons
        Button addButton = new Button("Add Student");
        Button deleteButton = new Button("Delete Selected");

        addButton.setDefaultButton(true);
        addButton.setOnAction(e -> addStudent());
        deleteButton.setOnAction(e -> deleteStudent());

        // Keyboard access
        nameField.setOnAction(e -> studentNumberField.requestFocus());
        studentNumberField.setOnAction(e -> courseField.requestFocus());
        courseField.setOnAction(e -> programField.requestFocus());
        programField.setOnAction(e -> addStudent());

        // Form
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        form.setPadding(new Insets(15));

        form.add(new Label("Name:"), 0, 0);
        form.add(nameField, 1, 0);

        form.add(new Label("Student Number:"), 0, 1);
        form.add(studentNumberField, 1, 1);

        form.add(new Label("Course:"), 0, 2);
        form.add(courseField, 1, 2);

        form.add(new Label("Program:"), 0, 3);
        form.add(programField, 1, 3);

        HBox buttons = new HBox(10, addButton, deleteButton);
        buttons.setPadding(new Insets(0, 15, 15, 15));

        BorderPane root = new BorderPane();
        root.setTop(form);
        root.setCenter(table);
        root.setBottom(buttons);
        BorderPane.setMargin(table, new Insets(0, 15, 15, 15));

        Scene scene = new Scene(root, 700, 500);
        stage.setScene(scene);
        stage.show();

        nameField.requestFocus();
    }

    private void addStudent() {
        String name = nameField.getText().trim();
        String studentNumber = studentNumberField.getText().trim();
        String course = courseField.getText().trim();
        String program = programField.getText().trim();

        // Validate all required fields
        if (name.isEmpty()) {
            showAlert(Alert.AlertType.ERROR,
                    "Invalid Input",
                    "Please enter the student's name.");
            nameField.requestFocus();
            return;
        }

        if (studentNumber.isEmpty()) {
            showAlert(Alert.AlertType.ERROR,
                    "Invalid Input",
                    "Please enter the student number.");
            studentNumberField.requestFocus();
            return;
        }

        if (course.isEmpty()) {
            showAlert(Alert.AlertType.ERROR,
                    "Invalid Input",
                    "Please enter the course.");
            courseField.requestFocus();
            return;
        }

        if (program.isEmpty()) {
            showAlert(Alert.AlertType.ERROR,
                    "Invalid Input",
                    "Please enter the program.");
            programField.requestFocus();
            return;
        }

        // Add student
        students.add(new Student(
                name,
                studentNumber,
                course,
                program
        ));

        // Clear fields after successful addition
        nameField.clear();
        studentNumberField.clear();
        courseField.clear();
        programField.clear();

        nameField.requestFocus();
    }

    private void deleteStudent() {
        Student selected = table.getSelectionModel().getSelectedItem();

        if (selected == null) {
            showAlert(Alert.AlertType.WARNING,
                    "No Selection",
                    "Please select a student to delete.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirm Deletion");
        confirmation.setHeaderText("Delete selected student?");
        confirmation.setContentText(
                "Student: " + selected.getName()
                        + "\nStudent Number: " + selected.getStudentNumber());

        confirmation.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                students.remove(selected);
            }
        });
    }

    private void showAlert(Alert.AlertType type,
                           String title,
                           String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
