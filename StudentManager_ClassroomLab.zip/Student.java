package studentmanager;

public class Student {
    private final String name;
    private final String studentNumber;
    private final String course;
    private final String program;

    public Student(String name, String studentNumber, String course, String program) {
        this.name = name;
        this.studentNumber = studentNumber;
        this.course = course;
        this.program = program;
    }

    public String getName() {
        return name;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public String getCourse() {
        return course;
    }

    public String getProgram() {
        return program;
    }
}
